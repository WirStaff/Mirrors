#include <steam/steam_gameserver.h>
#include <steam/isteamgameserver.h>
#include <iostream>

int main(int argc, char** argv)
{
    SteamGameServer_Init(0, atoi(argv[2]), MASTERSERVERUPDATERPORT_USEGAMESOCKETSHARE, eServerModeAuthentication, argv[3]);

    SteamGameServer()->SetProduct("730");
    SteamGameServer()->SetDedicatedServer(true);
    SteamGameServer()->SetModDir("csgo");

    SteamGameServer()->SetBotPlayerCount(0);
    SteamGameServer()->SetMaxPlayerCount(32);
    SteamGameServer()->SetRegion("255");
    SteamGameServer()->SetSpectatorPort(0);

    SteamGameServer()->SetServerName("Server Test");
    SteamGameServer()->SetMapName("de_dust2");
    SteamGameServer()->SetGameTags(argv[4]);
    SteamGameServer()->SetPasswordProtected(false);

    SteamGameServer()->LogOn(argv[1]);

    SteamGameServer()->SetAdvertiseServerActive(true);

    system("pause");

	return 0;
}