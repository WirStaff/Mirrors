const udp = require('dgram');
const { execFile } = require('child_process');

const servers = require('./servers.json');

//console.log(servers.tokens.length);

for (let i = 0; i < servers.tokens.length; i++)
{
    const socket = udp.createSocket('udp4');
    socket.bind(servers.startPort + i, '0.0.0.0', () => {
        console.log('Start Port: ' + (servers.startPort + i));
        /*exec('mirror.exe ' + servers.tokens[i] + ' ' + (servers.startPort + i) + ' ' + servers.version + ' ' + servers.tags, (err, data) => {
            console.log(err);
            console.log(data);
        });*/
        execFile(__dirname + '\\mirror.exe', [servers.tokens[i], servers.startPort + i, servers.version, servers.tags], (err, data) => {
            console.log(err);
            console.log(data);
        });
        socket.on('message', messageEvent);
    });
}

let response = [
    0xff, 0xff, 0xff, 0xff, 0x49, 0x11
];

const hostname = servers.hostname;
const map = servers.map;
const folder = 'csgo';
const game = 'Counter Strike: Global Offensive';
const version = '1.38.3.1';
const tags = servers.tags;

for (let i = 0; i < hostname.length; i++) {
    response.push(hostname.charCodeAt(i).toString(10));
}

response.push(0x00);
for (let i = 0; i < map.length; i++) {
    response.push(map.charCodeAt(i).toString(10));
}

response.push(0x00);
for (let i = 0; i < folder.length; i++) {
    response.push(folder.charCodeAt(i).toString(10));
}

response.push(0x00);
for (let i = 0; i < game.length; i++) {
    response.push(game.charCodeAt(i).toString(10));
}
response.push(0x00);
/*
AppId
 */
response.push(0xDA);
response.push(0x02);

response.push(0x0F); // Количество игроков
response.push(servers.maxPlayers); // Максимальное количество игроков
response.push(0x00); // Количество ботов

response.push('d'.charCodeAt(0).toString(10)); // dedicated
response.push('w'.charCodeAt(0).toString(10)); // OS

response.push(0x00); // Public

response.push(0x01); // Vac

for (let i = 0; i < version.length; i++) {
    response.push(version.charCodeAt(i).toString(10));
}
response.push(0x00);


response.push(0xa1); // i
// Порт сервера
response.push(0x88);
response.push(0x69);

for (let i = 0; i < tags.length; i++) {
    response.push(tags.charCodeAt(i).toString(10));
}
response.push(0x00); // Если есть тэги

response.push(0xda);
response.push(0x02);

response.push(0x00); // END
response.push(0x00); // END
response.push(0x00); // END
response.push(0x00); // END
response.push(0x00); // END
response.push(0x00); // END

const message = 'ConnectRedirectAddress:';
const server = servers.redirect;

let redirect = [
    0xff, 0xff, 0xff, 0xff, 0x39
];

for (let i = 0; i < message.length; i++) {
    redirect.push(message.charCodeAt(i).toString(10));
}

for (let i = 0; i < server.length; i++) {
    redirect.push(server.charCodeAt(i).toString(10));
}

redirect.push(0x00);

function messageEvent(message, rinfo) {
    if (message[4] === 0x54) {
        let startPort = response.length - (9 + tags.length + 2);
        const port = this.address().port;

        response[startPort] = port & 0xFF;
        response[startPort + 1] = (port >> 8) & 0xFF;

        response = new Uint8Array(response);
        this.send(response, 0, response.length, rinfo.port, rinfo.address);
    } else if (message[4] === 0x71) {
        redirect = new Uint8Array(redirect);
        this.send(redirect, 0, redirect.length, rinfo.port, rinfo.address);
    }
}